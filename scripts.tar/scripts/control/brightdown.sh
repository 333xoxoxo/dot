#!/bin/bash

rn=$(xbacklight -get)
if [ "$rn" -gt 5 ]; then 
	xbacklight -dec 5
else
	xbacklight -set 1
fi
