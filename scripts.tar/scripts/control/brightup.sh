#!/bin/bash

rn=$(xbacklight -get)

if [ "$rn" == 1 ]; then
	xbacklight -set 5
else
	xbacklight -inc 5
fi
