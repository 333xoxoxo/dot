#!/bin/bash

pactl set-source-mute 1 toggle
pkill status.sh
~/scripts/status.sh
