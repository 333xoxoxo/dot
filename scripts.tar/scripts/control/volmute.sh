#!/bin/bash

pactl set-sink-mute 0 toggle
pkill status.sh
~/scripts/status.sh &
