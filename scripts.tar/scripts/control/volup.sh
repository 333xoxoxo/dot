#!/bin/bash

pactl set-sink-mute 0 0
pactl set-sink-volume 0 +5%
pkill status.sh
~/scripts/status.sh &
