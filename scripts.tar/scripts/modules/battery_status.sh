#!/bin/bash

level=$(acpi -b | awk '{print $4}' | cut -d '%' -f1)
state=$(acpi -b | awk '{print $3}')

if [ "$state" == "Discharging," ]; then

	if [ "$level" -gt 74 ]; then
		state_icon="󱊣"
	elif [ "$level" -gt 24 ]; then
		state_icon="󱊢"
	else
		state_icon="󱊡"
	fi

elif [ "$state" == "Charging," ]; then
	state_icon="󰂄"

elif [ "$state" == "Full," ]; then
	state_icon="󰂃"

else
	state_icon="󰂑"
	level=$(acpi -b | awk '{print $5}' | cut -d '%' -f1)
fi

echo $state_icon $level%
