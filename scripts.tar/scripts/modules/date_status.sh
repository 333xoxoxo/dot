#!/bin/bash

date=$(date +"%a %d/%m/%Y %H:%M")

echo $date
