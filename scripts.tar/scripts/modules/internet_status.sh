#!/bin/bash

if ip link show wlp61s0 | grep -q 'state UP'; then
    echo "󰖩"
    exit 0
elif ip link show enp0s31f6  | grep -q 'state UP'; then
    echo "󰒢"
    exit 0
else
    echo "󰞃"
    exit 0
fi
