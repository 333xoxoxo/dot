#!/bin/bash
volume=$(pactl list sinks | awk '/Sink #0/ { found = 1 } found && /Volume:/ { print $5; exit }')
mic_muted=$(pactl list sources | awk '/Source #1/ { found = 1 } found && /Mute:/ { print $2; exit }')
volume_muted=$(pactl list sinks | awk '/Sink #0/ { found = 1 } found && /Mute:/ { print $2; exit }')

if [ "$volume_muted" == "yes" ]; then
    volsymbol="󰖁"  
else
    volsymbol="󰕾"  
fi

if [ "$mic_muted" == "yes" ]; then
    micsymbol="󰍭"  
else
    micsymbol="󰍬"  
fi

if [ "$volume_muted" == "yes" ]; then
	echo "$micsymbol $volsymbol "
else
	echo "$micsymbol $volsymbol $volume"
fi
