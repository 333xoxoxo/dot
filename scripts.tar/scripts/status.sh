#!/bin/bash

trap "exit" SIGTERM

volume=$(~/scripts/modules/volume_status.sh)

counter=0

while true
do
    date=$(~/scripts/modules/date_status.sh)
    if (( counter % 5 == 0 )); then
        battery=$(~/scripts/modules/battery_status.sh)
	internet=$(~/scripts/modules/internet_status.sh)
    fi
    xsetroot -name " $internet  $volume $battery $date"
    (( counter++ ))
    sleep 1
done
